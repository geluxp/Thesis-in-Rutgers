

total_pop=zeros(9,19);
for i=2:53
  if i==15||i==16||i==19||i==27||i==37||i==44||i==50
      
% Central
% Illinois (IL)
% Indiana (IN)
% Kentucky (KY)
% Missouri (MO)
% Ohio (OH)
% Tennessee (TN)
% West Virginia (WV)
    j=1;
     str='HD01_S';
    for k=2:19
    total_pop(j,k-1)=total_pop(j,k-1)+eval([str,num2str(k),'(i)']);
    end

    
%   elseif i==17||i==24||i==25||i==51
% %East North Central
% % 
% % Iowa (IA)
% % Michigan (MI)
% % Minnesota (MN)
% % Wisconsin (WI)
%     j=2;
%      str='HD01_S';
%     for k=2:19
%     total_pop(j:k)=total_pop(j:k)+eval([str,num2str(k),'(i)']);
%     end
% 
% 
%       elseif i==8||i==9||i==21||i==22||i==23||i==31||i==32||i==34||i==40||i==41||i==47
% % Northeast
% % 
% % Connecticut (CT)
% % Delaware (DE)
% % Maine (ME)
% % Maryland (MD)
% % Massachusetts (MA)
% % New Hampshire (NH)
% % New Jersey (NJ)
% % New York (NY)
% % Pennsylvania (PA)
% % Rhode Island (RI)
% % Vermont (VT)
% % 
%    j=3;
%     str='HD01_S';
%     for k=2:19
%     total_pop(j:k)=total_pop(j:k)+eval([str,num2str(k),'(i)']);
%     end
% 
% 
%           elseif i==14||i==39||i==49
% % 
% % Idaho (ID)
% % Oregon (OR)
% % Washington (WA)
%  j=4;
%       str='HD01_S';
%     for k=2:19
%     total_pop(j:k)=total_pop(j:k)+eval([str,num2str(k),'(i)']);
%     end
%      elseif i==5||i==18||i==20||i==26||i==38||i==45
%                       
% % South
% % 
% % Arkansas (AR)
% % Kansas (KS)
% % Louisiana (LA)
% % Mississippi (MS)
% % Oklahoma (OK)
% % Texas (TX)
% % 
% 
%  j=5;
%      str='HD01_S';
%     for k=2:19
%     total_pop(j:k)=total_pop(j:k)+eval([str,num2str(k),'(i)']);
%     end
% 
%                   elseif i==2||i==10||i==11||i==12||i==35||i==42||i==48
% % Southeast
% % 
% % Alabama (AL)
% % Florida (FL)
% % Georgia (GA)
% % North Carolina (NC)
% % South Carolina (SC)
% % Virginia (VA)
% j=6;
%     str='HD01_S';
%     for k=2:19
%     total_pop(j:k)=total_pop(j:k)+eval([str,num2str(k),'(i)']);
%     end
% 
% % 
%                       elseif i==4||i==7||i==33||i==46
% % Southwest
% % 
% % Arizona (AZ)
% % Colorado (CO)
% % New Mexico (NM)
% % Utah (UT)
% % 
% 
% j=7;
%     str='HD01_S';
%     for k=2:19
%     total_pop(j:k)=total_pop(j:k)+eval([str,num2str(k),'(i)']);
%     end
% 
%                           elseif i==6||i==30
% % West
% % 
% % California (CA)
% % Nevada (NV)
% % 
% 
% j=8;
%      str='HD01_S';
%     for k=2:19
%     total_pop(j:k)=total_pop(j:k)+eval([str,num2str(k),'(i)']);
%     end
% 
%                               elseif i==28||i==29||i==36||i==43||i==52
% % West North Central
% % 
% % Montana (MT)
% % Nebraska (NE)
% % North Dakota (ND)
% % South Dakota (SD)
% % Wyoming (WY)
% 
%  j=9;
%    str='HD01_S';
%     for k=2:19
%     total_pop(j:k)=total_pop(j:k)+eval([str,num2str(k),'(i)']);
%     end


  end
end
     

   
